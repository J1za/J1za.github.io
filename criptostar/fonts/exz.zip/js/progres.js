$(function(){
	var progressBar = $('#progressbar');
	$('#file_frm').on('submit', function(e){
		e.preventDefault();
		var $that = $(this),
				formData = new FormData($that.get(0));
		$.ajax({
			url: $that.attr('action'), //здесь даем ссылку на файл загрузки
			type: $that.attr('method'),
			contentType: false,
			processData: false,
			data: formData,
			dataType: 'json',
			xhr: function(){
				var xhr = $.ajaxSettings.xhr(); // объект XMLHttpRequest
				xhr.upload.addEventListener('progress', function(evt){ // добавляем обработчик события progress (onprogress)
					if (evt.lengthComputable) {
									// высчитываем процент загруженного
						var percentComplete = Math.ceil(evt.loaded/evt.total * 100);
      progressBar.val(percentComplete).text('Загружено ' + percentComplete + '%');
      $('#tot').html(percentComplete + '%');
      $('#totval').html('Общий размер файла <b>'+numeric_format(((evt.total/1024)/1024).toFixed(3))+' Mb.'); // размер файла
      $('#load').html('Всего загружено  <b>'+numeric_format(((evt.loaded/1024)/1024).toFixed(3))+' Mb.');// всего скачано
      if(percentComplete==100) { $('#saces').text( "Загрузка завершена!" ).show(); $('#pole').show(); }
					}
				}, false);
				return xhr;
			},
			success: function(json){
				if(json){
					$that.after(json);
				}
			}
		});
	});
	
	function numeric_format(val, thSep, dcSep) {

    // Проверка указания разделителя разрядов
    if (!thSep) thSep = ' ';

    // Проверка указания десятичного разделителя
    if (!dcSep) dcSep = ',';

    var res = val.toString();
    var lZero = (val < 0); // Признак отрицательного числа

    // Определение длины форматируемой части
    var fLen = res.lastIndexOf('.'); // До десятичной точки
    fLen = (fLen > -1) ? fLen : res.length;

    // Выделение временного буфера
    var tmpRes = res.substring(fLen);
    var cnt = -1;
    for (var ind = fLen; ind > 0; ind--) {
        // Формируем временный буфер
        cnt++;
        if (((cnt % 3) === 0) && (ind !== fLen) && (!lZero || (ind > 1))) {
            tmpRes = thSep + tmpRes;
        }
        tmpRes = res.charAt(ind - 1) + tmpRes;
    }

    return tmpRes.replace('.', dcSep);

}
	
});
