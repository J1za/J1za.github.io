<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Ajax загрузка файлов</title>
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
</head>

<body>
<form action="handler.php" method="post" id="my_form" enctype="multipart/form-data">
	<p>
    <label for="myfile">Файл:</label>
      <input type="file" name="my_file" id="my_file"> 
      	<progress id="progressbar" value="0" max="100"></progress>
  </p>
  <input type="submit" id="submit" value="Отправить">
</form>
</body>
</html>
