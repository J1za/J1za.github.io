<!DOCTYPE HTML><html><body><head><meta charset="utf-8">
<link href="js/style.css" type="text/css" media="all" rel="stylesheet">
<script src="js/min1.11.1.js"></script>
<script type="text/javascript" src="js/progres.js"></script>
<script type="text/javascript">
function getFileName () {
var file = document.getElementById ('my_file').value;
file = file.replace (/\\/g, "/").split ('/').pop();
document.getElementById ('file-name').innerHTML = 'Имя файла: <b>' + file + '</b>';
}
</script>
</head>
<div class="wrapper html5-progress-bar">
		<div class="progress-bar-wrapper">
<div align="center"><h1>Загрузка файла с индикатором progressBar</h1>
<div class="txt">Размер загружаемого файла от 2 Мб. Расширение любое. Файл не загружается на сервер
а происходит эмуляция загрузки. При небольшом объеме невозможно проследить плавную индикацию. Можно использовать файлы
аудио mp3 или видео</div></div>
 <form method="post" id="file_frm" enctype="multipart/form-data">
<table width="100%" border="0" class="txt">
<tr><td height="70px" colspan="2">
<div class="file-upload">
<label>
<input type="file" name="file" id="my_file" onchange="getFileName();">
<span>Выберите файл</span>
</label>
</div>
<div id="file-name"></div>
			</td></tr>
<tr><td height="70px" width="85%"><progress id="progressbar" width="500px" value="0" max="100"></progress></td>
<td width="15%" class="txt2" id="tot"></td></tr>
<tr><td align="center" colspan="2"><span class="txt2" id="totval"></span></td></tr>
<tr><td align="center" colspan="2"><span class="txt2" id="load"></span></td></tr>
<tr><td align="center" colspan="2" id="pole"><span class="only" id="saces"></span></td></tr>
<tr><td align="center" colspan="2" height="70px"><input type="submit" class="btreg" id="submit" value="Загрузить файл"></td></tr></table>
</form>
</div>
	</div>
</body>

</html>
